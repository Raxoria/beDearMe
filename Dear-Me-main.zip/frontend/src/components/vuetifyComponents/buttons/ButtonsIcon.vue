<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Icons -->
  <!-- ----------------------------------------------------------------------------- -->
  <div class="d-flex flex-wrap gap-2">
      
      <v-btn
        icon="mdi-heart"
        color="primary"
      ></v-btn>

      <v-btn
        icon="mdi-star"
        color="secondary"
      ></v-btn>

      <v-btn
        icon="mdi-cached"
        color="warning"
      ></v-btn>

      <v-btn
        icon="mdi-thumb-up"
        color="success"
      ></v-btn>
  </div>
</template>
