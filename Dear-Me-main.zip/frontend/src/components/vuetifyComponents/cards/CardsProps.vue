<script setup lang="ts"></script>

<template>
  <!-- ----------------------------------------------------------------------------- -->
  <!-- Props -->
  <!-- ----------------------------------------------------------------------------- -->
  <v-card
    title="This is a title"
    subtitle="This is a subtitle"
    text="This is content"
  ></v-card>
</template>
