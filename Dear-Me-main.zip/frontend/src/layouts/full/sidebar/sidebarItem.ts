export default [
  {
    title: "Dashboard",
    icon: "mdi-view-dashboard-outline",
    to: "/dashboard",
  },
  {
    title: "My Journal",
    icon: "mdi-book",
    to: "/ui-components/alert",
  },
  {
    title: "About Us",
    icon: "mdi-account-multiple",
    to: "/ui-components/buttons",
  },
  // {
  //   title: "Cards",
  //   icon: "mdi-card-outline",
  //   to: "/ui-components/cards",
  // },
  // {
  //   title: "Menus",
  //   icon: "mdi-form-dropdown",
  //   to: "/ui-components/menus",
  // },
  // {
  //   title: "Tables",
  //   icon: "mdi-table",
  //   to: "/ui-components/tables",
  // },
];
