<template>
  <v-flex d-flex xs12 sm6 md4>
 <v-card
   class="mx-auto my-12"
   max-width="374"
 >
   <template slot="progress">
     <v-progress-linear
       color="deep-purple"
       height="10"
       indeterminate
     ></v-progress-linear>
   </template>

   <v-card-title>
     <v-row
       class="justify-center"
     >KELOMPOK J2
     </v-row>
   </v-card-title>
 </v-card>
</v-flex>


  <v-flex d-flex xs12 sm6 md4>
 <v-card
   class="mx-auto my-12"
   max-width="374"
 >
   <template slot="progress">
     <v-progress-linear
       color="deep-purple"
       height="10"
       indeterminate
     ></v-progress-linear>
   </template>

   <v-img
     height="250"
     src="https://akademik.polban.ac.id/fotomhsrekap/201524010.jpg"
   ></v-img>

   <v-card-title>
     <v-row
       class="justify-center"
     >Hasanah
     </v-row>
   </v-card-title>

   <v-card-text>
     <v-row
       class="justify-center"
     >201524010
     </v-row>
   </v-card-text>
 </v-card>
</v-flex>

<v-flex d-flex xs12 sm6 md4>
 <v-card
   class="mx-auto my-12"
   max-width="374"
 >
   <template slot="progress">
     <v-progress-linear
       color="deep-purple"
       height="10"
       indeterminate
     ></v-progress-linear>
   </template>

   <v-img
     height="250"
     src="https://akademik.polban.ac.id/fotomhsrekap/201524014.jpg"
   ></v-img>

   <v-card-title>
     <v-row
       class="justify-center"
     >Taufiq
     </v-row>
   </v-card-title>

   <v-card-text>
     <v-row
       class="justify-center"
     >201524014
     </v-row>
   </v-card-text>
 </v-card>
</v-flex>

<v-flex d-flex xs12 sm6 md4>
 <v-card
   class="mx-auto my-12"
   max-width="374"
 >
   <template slot="progress">
     <v-progress-linear
       color="deep-purple"
       height="10"
       indeterminate
     ></v-progress-linear>
   </template>

   <v-img
     height="250"
     src="https://akademik.polban.ac.id/fotomhsrekap/201524020.jpg"
   ></v-img>

   <v-card-title>
     <v-row
       class="justify-center"
     >Nabiilah
     </v-row>
   </v-card-title>

   <v-card-text>
     <v-row
       class="justify-center"
     >201524020
     </v-row>
   </v-card-text>
 </v-card>
</v-flex>

<v-flex d-flex xs12 sm6 md4>
 <v-card
   class="mx-auto my-12"
   max-width="374"
 >
   <template slot="progress">
     <v-progress-linear
       color="deep-purple"
       height="10"
       indeterminate
     ></v-progress-linear>
   </template>

   <v-img
     height="250"
     src="https://akademik.polban.ac.id/fotomhsrekap/201524031.jpg"
   ></v-img>

   <v-card-title>
     <v-row
       class="justify-center"
     >Syelvie
     </v-row>
   </v-card-title>

   <v-card-text>
     <v-row
       class="justify-center"
     >201524031
     </v-row>
   </v-card-text>
 </v-card>
</v-flex>
</template>



